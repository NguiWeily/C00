/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_combn.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42singapore.sg>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/20 18:48:38 by wngui             #+#    #+#             */
/*   Updated: 2023/06/21 19:16:56 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_print_combn_recursive(int n, int start, int current, int number)
{
	if (current == n)
	{
		int i = 1;
		while (i <= n)
		{
			ft_putchar(number % 10 + '0');
			number /= 10;
			i++;
		}
		if (number != 0)
		{
			ft_putchar(',');
			ft_putchar(' ');
		}
	}
	else
	{
		int i = start;
		while (i <= 9)
		{
			ft_print_combn_recursive(n, i + 1, current + 1, number * 10 + i);
			i++;
		}
	}
}

void	ft_print_combn(int n)
{
	ft_print_combn_recursive(n, 0, 1, 0);
}
/*
int	main(void)
{
	ft_print_combn(2);
	return (0);
}*/
